# 将doc文件批量转为docx(doc2docx)
使用指南请访问作者博客：http://blog.csdn.net/zzti_erlie/article/details/78922112</br>
doc2docx.py是生成的界面的代码</br>
doc2docx.ui是图形界面文件</br>
doc2docx2.py是逻辑代码</br>
docx2excel部分可直接忽略，作者自己用的工具</br>
![欢迎fork和star](https://github.com/erlieStar/image/blob/master/%E6%AC%A2%E8%BF%8Efork%E5%92%8Cstar.jpg)